setwd("C:\\Users\\ASUS\\Desktop\\IT24100671")
getwd()

# Question 1
# X follows uniform distribution between 0 and 40 minutes
prob_train <- punif(25, min=0, max=40, lower.tail=TRUE) - punif(10, min=0, max=40, lower.tail=TRUE)
print(prob_train)

# Question 2
# X follows exponential distribution with rate = 1/3
prob_update <- pexp(2, rate=1/3, lower.tail=TRUE)
print(prob_update)

# Question 3
# i.
prob_iq_above_130 <- 1 - pnorm(130, mean=100, sd=15, lower.tail=TRUE)
print(prob_iq_above_130)

# ii.
iq_95th_percentile <- qnorm(0.95, mean=100, sd=15, lower.tail=TRUE)
print(iq_95th_percentile)
